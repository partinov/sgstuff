#!/bin/bash

clipboard=$(pbpaste)

case "${clipboard%% *}" in 
    "Hostname:" | "Nombre" | "Nome")
        credentials=$clipboard ;;

    *) 
        printf "Enter credentials:\033[1;33m \n"
        credentials=$(cat | grep "\S");;
esac

hostname=$(echo "$credentials" | awk 'NF>1{print $NF}' | head -n 1)
username=$(echo "$credentials" | awk 'NF>1{print $NF}' | head -n 2 | tail -n1)


printf "\n\033[0mhost: $hostname\n"
echo "user: $username \n\n"

cmd=$(ssh $username@$hostname -p18765 -o "StrictHostKeyChecking no" \
'echo -e "\033[0;36m====>\033[0m temporary files \033[0;33m(/tmp)\033[0m \033[0;36m<====\033[0m"; \
echo "size:"; \
du -csh ~/tmp 2>/dev/null | head -n1 | cut -f1; \
echo "inodes:"; \
find ~/tmp 2>/dev/null | wc -l; \
echo "flushing..."; \
cd /tmp; \
find . ! \( -name "*.sock" -o -name "*.conf" \) -delete 2>/dev/null; \
echo -e "\033[0;32mflushed\033[0m\n\n"; \
echo -e "\033[0;36m====>\033[0m opcache \033[0;33m(/.opcache)\033[0m \033[0;36m<====\033[0m"; \
echo "size:"; \
du -csh ~/.opcache 2>/dev/null | head -n1 | cut -f1; \
echo "inodes:"; \
find ~/.opcache 2>/dev/null | wc -l; \
echo "flushing..."; \
rm ~/.opcache -rf 2>/dev/null; \
echo -e "\033[0;32mflushed\033[0m\n"; \
echo -e "Please \033[0;31mdelete\033[0m your public key from Site Tools."; \
exit;')

echo "${cmd}"
