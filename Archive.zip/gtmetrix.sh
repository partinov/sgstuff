#!/bin/bash
# Function that locates the GTMetrix nearest server.

domain=$1

function getlocation () {
    local dc=$(curl --silent --max-time 5 --show-error --fail -k "https://$domain/.well-known/srvinfo/dc")

    case $dc in
        GG-NLD|GG-LON|GG-FRA)
            location_id="2"
            location="London, UK"
            server_location="Europe"

        ;;
        GG-IOW)
            location_id="4"
            location="San Antonio, TX, USA"
            server_location="USA"

        ;;
        GG-SGP)
            location_id="7"
            location="Hong Kong, China"
            server_location="Singapore"

        ;;
        GG-SYD)
            location_id="3"
            location="Sydney, Australia"
            server_location="Australia"
        ;;
        *)
            location_id="2"
            location="London, UK"
            server_location="Unknown."
        ;;

    esac


}

getlocation

echo "Running from $location"

function gtmetrix() {
	wpptest=$(curl -s https://kb.sitegroundtechsupport.com/automation/wpptest/wpptest.php | grep credentials -A 2)
	gmuser=$(echo $wpptest | grep gmuser= | awk -F '"' '{print $2}')
	gmapikey=$(echo $wpptest | grep gmapikey= | awk -F '"' '{print $4}')

	local gtstart=$(curl -s --user $gmuser:$gmapikey --form url=$domain --form x-metrix-adblock=0 --form location=$location_id https://gtmetrix.com/api/0.1/test)

    local reportid=$(echo $gtstart | jq -r '.test_id')
    local credits=$(echo $gtstart | jq -r '.credits_left')
	if [[ $credits > 0 ]]
		then
			local statuscheck=$(curl -s --user $gmuser:$gmapikey --form url=$domain -X GET https://gtmetrix.com/api/0.1/test/$reportid | jq -r '.state')
			local timer=0
			while [[ $statuscheck != "completed" ]] || [[ $timer < 60 ]]
				do
				sleep 3
				local statuscheck=$(curl -s --user $gmuser:$gmapikey --form url=$domain -X GET https://gtmetrix.com/api/0.1/test/$reportid | jq -r '.state')
				timer=$((timer+3))
			done
	fi

        if [[ $statuscheck = "completed" ]]; then

        local results=$(curl -s --user $gmuser:$gmapikey --form url=$domain -X GET https://gtmetrix.com/api/0.1/test/$reportid)
        local testurl=$(echo $results | jq -r '.results | .report_url')
        local loadtime=$(echo $results | jq -r '.results | .fully_loaded_time')
        local requests=$(echo $results | jq -r '.results | .page_elements')
        local pagesize=$(echo $results | jq -r '.results | .page_bytes')

        echo "➜ GTMetrix: $testurl"
        fi

}

echo "➜ PageSpeed Insights: https://pagespeed.web.dev/report?url=https%3A%2F%2F$domain%2F&form_factor=desktop"
gtmetrix
