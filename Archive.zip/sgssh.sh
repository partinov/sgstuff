#!/bin/bash

clipboard=$(pbpaste)

case "${clipboard%% *}" in
    "Hostname:" | "Nombre" | "Nome")
    credentials=$clipboard ;;

    *) 
    printf "Enter credentials:\033[1;33m \n"
    credentials=$(cat | grep "\S");;
esac

hostname=$(echo "$credentials" | awk 'NF>1{print $NF}' | head -n 1)
username=$(echo "$credentials" | awk 'NF>1{print $NF}' | head -n 2 | tail -n1)


printf "\n\033[0mhost: $hostname\n"
echo "user: $username \n\n"

ssh $username@$hostname -p18765 -o "StrictHostKeyChecking no"
