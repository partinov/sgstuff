#!/bin/bash

RAW_DOMAIN=$1

NC='\033[0m' 
GREEN='\033[0;32m'
RED='\033[0;31m'
CYAN='\033[0;36m' 


if [[ ${#RAW_DOMAIN} -lt 4 ]]; then
    printf "${RED}No params ${NC}\n"
    exit 0
fi

DOMAIN=${RAW_DOMAIN#*//}
DOMAIN=${DOMAIN%/*}
echo "Stripping domain... ${RAW_DOMAIN} -> ${DOMAIN}"

echo "Testing for SiteGround ping..."
ping=$(curl -IX GET "{$DOMAIN}/.well-known/sg-hosted-ping" -s --connect-timeout 3 | grep ^HTTP)
node=$(curl -IX GET "{$DOMAIN}/.well-known/srvinfo/node" -s --connect-timeout 3 | grep ^HTTP)

echo "\n\n\n\n\n"

sg=true

function print_hosted() {
    printf "${GREEN}===========================\n"
    echo ">> OPENS FROM SITEGROUND <<"
    printf "===========================${NC}"
}

function print_not_hosted() {
    printf "${RED}=========================\n"
    echo ">> NOT WITH SITEGROUND <<"
    printf "=========================${NC}"
}

if [[ $ping == *"200 OK"*  ]]; then
    print_hosted
elif [[ $node == *"200 OK"* ]]; then
    echo "➜ sg-hosted-ping:${RED}" $(echo $ping | awk '{print $2}') "${NC}| node: ${GREEN}200${NC}"
    print_hosted
else
    print_not_hosted
    sg=false
fi

homepage=$(curl -s "https://{$DOMAIN}" --connect-timeout 3)
link_headers=$(curl "https://{$DOMAIN}" --connect-timeout 3 -s | grep ^link)

if [[ $homepage == *"wp-content"* || $link_headers == *"w.org"* ]]; then
    echo "\n${CYAN}>${NC}Based on ${CYAN}WordPress${NC}"
fi

NS=$(dig ${DOMAIN} NS +short)
printf "\n\n${CYAN}>> NAMESERVERS:${NC}\n"
echo "${NS}"

function check_CDN () {
    if ! $sg
    then
        cloudflare=$(curl -IX GET "{$DOMAIN}" -s --connect-timeout 3 | grep ^CF)
	if [[ $cloudflare == *"CF-"* ]]; then
    	    printf "${RED}CDN:${NC} Cloudflare\n"
	fi
        return 1
    fi

    printf "${GREEN}CDN: ${NC}"

    case $A in

        "34.121.194.18")
            echo "(Council Bluffs, Iowa, North America) us-central1.lb"
            ;;

        "35.197.227.153")
            echo "(St. Ghislain, Belgium, Europe) europe-west2.lb"
            ;;

        "35.242.224.42")
            echo "(Frankfurt, Germany Europe) europe-west3.lb"
            ;;

        "34.91.95.185")
            echo "(Eemshaven, Netherlands, Europe) europe-west4.lb"
            ;;

        "34.116.197.74")
            echo "(Warsaw, Poland, Europe) europe-central2.lb"
            ;;

        "34.94.142.247")
            echo "(Los Angeles, California, North America) us-west2.lb"
            ;;

        "34.146.32.226")
            echo "(Tokyo, Japan, APAC) asia-northeast1.lb"
            ;;

        "34.126.176.189")
            echo "(Jurong West, Singapore, APAC) asia-southeast1.lb"
            ;;

        "34.151.73.51")
            echo "(Sydney, Australia, APAC) australia-southeast1.lb"
            ;;

        "34.88.171.62")
            echo "(Hamina, Finland, Europe) europe-north1.lb"
            ;;

        "104.196.162.239")
            echo "(Moncks Corner, South Carolina, North America) us-east1.lb"
            ;;

        "34.82.71.169")
            echo "(The Dalles, Oregon, North America) us-west1.lb"
            ;;

        *)
            cdn=$(curl -IX GET "{$DOMAIN}/.well-known/sg-hosted-ping" -s --connect-timeout 3 | grep ^X-SG-CDN)
            cloudflare=$(curl -IX GET "{$DOMAIN}/.well-known/sg-hosted-ping" -s --connect-timeout 3 | grep ^CF)

            if [[ $cdn == *"1"* ]]; then
            	echo "enabled (other SiteGround CDN nodes)"
            elif [[ $cloudflare == *"CF-"* ]]; then
            	echo "enabled (${RED}Cloudflare${NC})"
            else
                printf "${RED}not enabled ${NC}\n"
            fi
            ;;
    esac
}

A=$(dig ${DOMAIN} A +short)
printf "\n${CYAN}>> A records:${NC}\n"
echo "${A}"
wwwA=$(dig www.${DOMAIN} A +short)
if [[ $wwwA != *"${wwwA}"* ]]; then
    printf "${RED}WWW A record is different:${NC} ${wwwA}\n"
fi

host=$(host ${A} 2>/dev/null)
if [[ $host == *"welcome.com"* ]]; then
    printf "${RED}Hostgator${NC}\n"
elif [[ $host == *"bluehost.com"* ]]; then
    printf "${RED}BlueHost${NC}\n"
elif [[ $host == *"secureserver.net"* ]]; then
    printf "${RED}GoDaddy${NC}\n"
fi
check_CDN


MX=$(dig ${DOMAIN} MX +short)
printf "\n${CYAN}>> MX records:${NC}\n"
echo "${MX}"

printf "\n${CYAN}>> SSL:${NC}\n"
if [[ $(dig +short ${DOMAIN} AAAA) ]]; then
    printf "${RED}➜ Domain has AAAA records. ${NC}\n"
    printf "${RED}! May cause issues with issuing SSL. ${NC}\n"
fi
if [[ $(dig +short ${DOMAIN} DS) ]]; then
    printf "${RED}➜ Domain has DNSSEC records. ${NC}\n"
    printf "${RED}! May cause issues with issuing SSL. ${NC}\n"
fi

~/./ssl ${DOMAIN}


if [[ $2 == "-l"* ]]; then
    printf "${CYAN}>>> LINKS: ${NC}"
    echo ""
    sh links.sh ${DOMAIN}
elif [[ $2 == "-gt"* && "$sg" == "true" ]]; then
    printf "${CYAN}>>> GTMetrix: ${NC}"
    echo ""
    sh gtmetrix.sh ${DOMAIN}
fi
