"use strict";

//chat elements
const chatCheck = document.getElementById("impulse-hb-label");
let soundDiv = document.getElementById("sounds");
let source = document.getElementsByTagName("source");

//default Sounds
const chatRing = "https://admin.chat-assistance.com/sounds/request.mp3";
const chatBeep = "https://admin.chat-assistance.com/sounds/beep.mp3";
const chatBeep1 = "https://admin.chat-assistance.com/sounds/beep1.mp3";

//custom Sounds
// const mySound = `https://www.warzon.info/chatSound/iphonering.mp3`;
// const mySound = `https://www.warzon.info/chatSound/ayyy.mp3`;
const mySound = `https://www.warzon.info/chatSound/phub.mp3`;
// const mySound = `https://www.warzon.info/chatSound/snoring.mp3`;
// const mySound = `https://warzon.info/chatSound/urod.mp3`;
const myBeep = `https://warzon.info/chatSound/winError.mp3`;

//using a Mutation Observer
const observerOptions = {
  childList: true,
  attributes: false,
  subtree: false,
};

//function to be executed once the DOM element is changed
const callback = () => {
  if (source[0].src === chatRing) {
    source[0].src = mySound;
  } else if (source[0].src === chatBeep || source[0].src === chatBeep1) {
    source[0].src = myBeep;
  }
};

//creation of the Observer object and assigning the callback() to use when a change happens
const observer = new MutationObserver(callback);

if (chatCheck) {
  console.log(
    "You are working I see. Let me change the sounds to make you feel better atleast."
  );
  observer.observe(soundDiv, observerOptions);
} else {
  console.log("Whew, you're not working today I see.");
}
