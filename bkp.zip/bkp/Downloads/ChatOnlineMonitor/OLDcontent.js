"use strict";

// Show popup <div> in body
const popup = `<div id='alert' style="
backdrop-filter: blur(10px);
z-index: 3;
text-align: center;
align-content: center;
width: 50%;
border: 3px solid green;
padding: 10px;
position: absolute;
top: 50%;
left: 30%;
">

<span>You are offline mate!</span><br>
<button id='break' style="
padding-top: 1px;
border-top-width: -;
margin-top: 10px;
margin-right: 3px;">Shit.. Thanks</button>

<button id='mistake'style="
padding-top: 1px;
border-top-width: -;
margin-top: 10px;
margin-right: 3px;">I did that</button>
</div>`;

const page = document.getElementsByTagName("BODY")[0];
page.innerHTML += popup;

//sounds
const statusElement = document.getElementById("teamstatus_2"); // The whole element
const statusElementToString = statusElement.outerHTML;

const onlineButtonElement =
  document.getElementsByClassName("monitoring-status")[0]; // The Online/Offline element

const onlineOrOffline = document
  .getElementsByClassName("monitoring-status")[0]
  .getElementsByTagName("p")[0].innerHTML; //Only the Online/Offline text

//using a Mutation Observer

const observerOptions = {
  childList: true,
  attributes: true,
  subtree: false,
};

//function to be executed once the DOM element is changed
const callbackSecondary = () => {
  if (onlineOrOffline === "Offline") {
    alert("You are offline mate!");
  }
  observerSecondary.disconnect();
};

const callbackMain = () => {
  if (onlineOrOffline === "Online") {
    observerSecondary.observe(onlineButtonElement, observerOptions);
  }
};

//creation of the Observer object and assigning the callback() to use when a change happens
const observerMain = new MutationObserver(callbackMain); // Main observer
const observerSecondary = new MutationObserver(callbackSecondary); // Secondary observer

observerMain.observe(statusElement, observerOptions);

/*
1. If you sign in - must be deactivated
2. When you are Online - it must start monitoring the div
3. If you're offline - Alert
4. If 'Ok' is clicked, kill the observer session and monitor for "Online again"
*/
