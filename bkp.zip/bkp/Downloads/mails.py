import sys

f = open('mails.txt', 'r')
line = 1

for l in f.readlines():
	if line == 1:
		print (l.split('\n')[0])
	elif line == 4:
		line = 0
	line += 1
	
#for w in sorted(sizes, key=sizes.get, reverse=True):
#    print w + ': ' + sizes[w]