"use strict";
//import chat data
const page = document.getElementsByTagName("BODY")[0];
let theFirstChild = page.firstChild;

//returns string Online or Offline
const elementNode = document.getElementById("teamstatus_2");

//render the new element on the page
const createElement = () => {
  //import styles for all elements
  const styles = document.createElement("style");
  styles.innerHTML = `
    .element-whole{
      z-index: 3;
      background-color: red;
      display: none;
      text-align: center;
    }

    .element-headline{
      display: inline-block;
      text-align: center;
      margin-top: 10px;
      margin-bottom: 20px;
      font-weight:700;
      font-size: 1.5rem;
    }
  `;
  //parent div componenet
  const warningDiv = document.createElement("div");
  warningDiv.classList.add("element-whole");
  warningDiv.setAttribute("id", "element-whole");

  //notification text
  const textContent = document.createElement("span");
  textContent.classList.add("element-headline");
  textContent.textContent = "You are offline mate!";

  warningDiv.appendChild(styles);
  warningDiv.appendChild(textContent);
  page.insertBefore(warningDiv, theFirstChild);
};

//checks if the current window is the SG Chat
if (elementNode) {
  createElement();
}

//checks to show the banner or not
const switchOnOff = () => {
  const statusCheck = document.querySelectorAll(".monitoring-status p")[0]
    .innerHTML;

  document.getElementById("element-whole").style.display =
    statusCheck === "Offline" ? "block" : "none";
};

//creates new observer for the Online/Offline Node
const observer = new MutationObserver(switchOnOff);

const observerOptions = {
  childList: true,
  attributes: true,
  subtree: true,
};

observer.observe(elementNode, observerOptions);
