Added:

 "permissions": ["tabs", "<all_urls>"],
  "background": {
    "scripts": ["content.js"]
  },
  "browser_action": {
    "default_popup": "popup.html"
  }

in manifest.json

Removed:
 "background": {
    "scripts": ["content.js"]
  }
  from manifest.json

Links for the Volume bar:

https://www.w3schools.com/howto/howto_js_rangeslider.asp
https://stackoverflow.com/questions/31639768/javascript-control-google-chromes-open-tab-audio-volume-control
https://stackoverflow.com/questions/10565058/javascript-controlling-audio-tag-in-background-html-in-a-chrome-extension